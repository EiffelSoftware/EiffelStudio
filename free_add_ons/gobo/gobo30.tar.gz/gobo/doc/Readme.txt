Documentation for Gobo Eiffel in HTML format.
Read `index.html' first.
