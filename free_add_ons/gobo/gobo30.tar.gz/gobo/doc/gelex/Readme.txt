Documentation for Gobo Eiffel Lex (gelex) in HTML format.
Read `index.html' first.
