VALIDITY VCFG

ETL2 p.52:
----------------------------------------------------------------------
A Formal_generics part of a Class_declaration is valid if and only
if every Formal_generic_name G appearing in it satisfies the following
two conditions:
1. G is different from the name of any class in the surrounding
   universe.
2. G is different from any other Formal_generic_name appearing in
   the same Formal_generics part.
----------------------------------------------------------------------

ETR p.16:
----------------------------------------------------------------------
A Formal_generics part of a Class_declaration is valid if and only
if every Formal_generic_name G appearing in it satisfies the following
three conditions:
1. G is different from the name of any class in the surrounding
   universe.
2. G is different from any other Formal_generic_name appearing in
   the same Formal_generics part.
3. If a Constraint is given, it does not involve any types other than
   class names and formal generic parameters other than G itself.
----------------------------------------------------------------------


TEST DESCRIPTION:
----------------------------------------------------------------------
The constraint of the first formal generic parameter G of class
CC is '-> DD [H]' and the second formal generic H is '-> DD [G]'.
Validity VCFG-3 is not violated.
----------------------------------------------------------------------


TEST RESULTS:
----------------------------------------------------------------------
ISE Eiffel 5.0.016:    FAILED    Reports a violation of VTCT (i.e.
                                 class H not in universe).
SmallEiffel -0.76:     FAILED    Does not report VCFG-3 and enters
                                 into an infinite loop.
Halstenbach 3.2:       FAILED    Reports a violation of VTCT (i.e.
                                 class H not in universe).
gelint:                OK
----------------------------------------------------------------------


TEST CLASSES:
----------------------------------------------------------------------
class AA

creation

	make

feature

	make is
		local
			b: BB
		do
			!! b
			b.g
			print (b.item1.generator)
			print (b.item2.generator)
			b.f
		end

end -- class AA
----------------------------------------------------------------------
class BB

inherit

	CC [EE, EE]

feature

	g is
		local
			e: EE
		do
			!! e
			item1 := e
			item2 := e
		end

end -- class BB
----------------------------------------------------------------------
class CC [G -> DD [H], H -> DD [G]]

feature

	item1: G
	item2: H

	f is
		do
			if item2 /= Void and item1 /= Void then
				item1.put (item2)
				print (item1.item.generator)
				item2.put (item1)
				print (item2.item.generator)
			end
		end

end -- class CC
----------------------------------------------------------------------
class DD [G]

feature

	item: G

	put (v: G) is
		do
			item := v
		end

end -- class DD
----------------------------------------------------------------------
class EE

inherit

	DD [EE]

end -- class EE
----------------------------------------------------------------------
