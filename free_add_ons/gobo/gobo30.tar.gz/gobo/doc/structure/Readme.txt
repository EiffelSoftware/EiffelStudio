Documentation for the Gobo Eiffel Structure Library in HTML format.
Read `index.html' first.
