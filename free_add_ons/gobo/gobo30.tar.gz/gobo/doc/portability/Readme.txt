Documentation on portability issues, in HTML format.
Read `index.html' first.
