Gobo Eiffel Test Library

This library provides testing functionalities. This library is mainly
used by Gobo Eiffel Test (getest). To get information about getest,
have a look at "$GOBO/src/getest/Readme.txt" and "$GOBO/doc/getest".
Examples for both getest and this library can be found in
"$GOBO/example/test".

Clusters:

config
    Test configuration file templates.
generation
    Generation of Eiffel class texts to build test programs.
    Source code for getest.
harness
    Test harness classes.

A more detailed documentation for this library will be provided in
future releases.

--
Copyright (c) 2000-2001, Eric Bezault and others
