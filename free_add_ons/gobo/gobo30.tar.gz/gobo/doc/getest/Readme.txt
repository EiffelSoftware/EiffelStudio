Documentation for Gobo Eiffel Test (getest) in HTML format.
Read `index.html' first.
