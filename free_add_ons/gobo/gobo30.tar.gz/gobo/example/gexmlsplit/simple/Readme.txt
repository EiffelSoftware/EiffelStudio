This directory contains a xml document which demonstrates how gexmlsplit
can be used. The file input.xml will be split up into the three files:

	* output1.xml
	* output2.xml
	* output3.xml

To split the file type:

	#gexmlsplit input.xml

--
Copyright (c) 2002, Eric Bezault and others
