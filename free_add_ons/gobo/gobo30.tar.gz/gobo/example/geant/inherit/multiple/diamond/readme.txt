Invocation:

	geant -v -b d1.eant cf

Expected output:
________________________________________________________________
Loading Project's configuration from d1.eant
Loading Project's configuration from D:\cvsstuff\gobo-eiffel\gobo/example/geant/inherit/multiple/diamond/b1.eant
Loading Project's configuration from D:\cvsstuff\gobo-eiffel\gobo/example/geant/inherit/multiple/diamond/a1.eant
Loading Project's configuration from D:\cvsstuff\gobo-eiffel\gobo/example/geant/inherit/multiple/diamond/c1.eant
Loading Project's configuration from D:\cvsstuff\gobo-eiffel\gobo/example/geant/inherit/multiple/diamond/a1.eant
Building Project

D.cf:

  [echo] this is D.cf

C.f:

  [echo] this is C.f

A.f:

  [echo] this is A.f
________________________________________________________________

